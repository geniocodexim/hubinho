import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Minus, Plus, ShoppingCart, Trash2, X } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { formatCurrency } from '@/lib/formatCurrency';

const Cart = ({ cart, navigateTo, updateQuantity, removeFromCart }) => {
  const [cep, setCep] = useState('');
  const [shippingCost, setShippingCost] = useState(null);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + (shippingCost || 0);

  const handleCepChange = (e) => {
    const value = e.target.value.replace(/\D/g, '');
    setCep(value);
  };

  const calculateShipping = () => {
    if (cep.length === 8) {
      setShippingCost(25.00);
      toast({
        title: "Frete calculado!",
        description: `Frete para o CEP ${cep} é de ${formatCurrency(25.00)}.`,
      });
    } else {
      toast({
        title: "CEP inválido",
        description: "Por favor, insira um CEP válido com 8 dígitos.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        <Button
          variant="ghost"
          onClick={() => navigateTo('home')}
          className="mb-6 text-[#BFC3C7] hover:text-[#FF8A00]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Continuar Comprando
        </Button>

        <h1 className="text-4xl font-bold mb-8">
          <span className="text-gradient-orange">Seu Carrinho</span>
        </h1>

        {cart.length === 0 ? (
          <div className="text-center py-20 bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl border border-[#FF8A00]/20">
            <ShoppingCart className="w-24 h-24 mx-auto text-[#FF8A00]/50 mb-4" />
            <h2 className="text-2xl font-bold text-[#E6E8EB] mb-2">Seu carrinho está vazio</h2>
            <p className="text-[#BFC3C7] mb-6">Adicione produtos para vê-los aqui.</p>
            <Button onClick={() => navigateTo('home')} className="bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] text-[#0E0E0E] font-bold glow-orange">
              Explorar Produtos
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <AnimatePresence>
                {cart.map((item) => (
                  <motion.div
                    key={`${item.id}-${item.selectedColor}-${item.selectedCapacity}`}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -50, transition: { duration: 0.3 } }}
                    className="flex items-center bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] p-4 rounded-lg border border-[#FF8A00]/20"
                  >
                    <img className="w-24 h-24 object-cover rounded-md mr-4" alt={item.name} src="https://images.unsplash.com/photo-1580728371486-c17d7e73f619" />
                    <div className="flex-grow">
                      <h3 className="font-bold text-lg text-[#E6E8EB]">{item.name}</h3>
                      <p className="text-sm text-[#BFC3C7]">Cor: {item.selectedColor}, Cap.: {item.selectedCapacity}</p>
                      <p className="text-lg font-semibold text-gradient-orange mt-1">{formatCurrency(item.price)}</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Button variant="outline" size="icon" className="w-8 h-8 bg-[#2a2a2a] border-[#BFC3C7]/30" onClick={() => updateQuantity(item.id, item.selectedColor, item.selectedCapacity, item.quantity - 1)}>
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="font-bold text-lg w-8 text-center">{item.quantity}</span>
                      <Button variant="outline" size="icon" className="w-8 h-8 bg-[#2a2a2a] border-[#BFC3C7]/30" onClick={() => updateQuantity(item.id, item.selectedColor, item.selectedCapacity, item.quantity + 1)}>
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <Button variant="ghost" size="icon" className="ml-4 text-red-500 hover:text-red-400" onClick={() => removeFromCart(item.id, item.selectedColor, item.selectedCapacity)}>
                      <Trash2 className="w-5 h-5" />
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] p-6 rounded-lg border border-[#FF8A00]/20 sticky top-24">
                <h2 className="text-2xl font-bold text-[#E6E8EB] mb-6">Resumo</h2>
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-[#BFC3C7]">
                    <span>Subtotal</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex items-end justify-between gap-4">
                    <div className="flex-grow">
                      <label htmlFor="cep" className="text-sm text-[#BFC3C7] mb-1 block">Calcular frete</label>
                      <Input
                        id="cep"
                        placeholder="Seu CEP"
                        value={cep}
                        onChange={handleCepChange}
                        maxLength={8}
                        className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]"
                      />
                    </div>
                    <Button onClick={calculateShipping} className="bg-transparent border border-[#FF8A00] text-[#FF8A00] hover:bg-[#FF8A00] hover:text-[#0E0E0E]">OK</Button>
                  </div>
                  {shippingCost !== null && (
                    <div className="flex justify-between text-[#BFC3C7]">
                      <span>Frete</span>
                      <span>{formatCurrency(shippingCost)}</span>
                    </div>
                  )}
                </div>
                <div className="flex justify-between text-2xl font-bold pt-4 border-t border-[#FF8A00]/20">
                  <span className="text-[#E6E8EB]">Total</span>
                  <span className="text-gradient-orange">{formatCurrency(total)}</span>
                </div>
                <Button
                  onClick={() => navigateTo('checkout')}
                  disabled={cart.length === 0}
                  className="w-full mt-6 py-6 text-lg bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] hover:from-[#FFB84D] hover:to-[#FF8A00] text-[#0E0E0E] font-bold glow-orange disabled:opacity-50"
                >
                  Finalizar Compra
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;