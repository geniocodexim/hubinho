import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Truck, CreditCard, Award } from 'lucide-react';
import ProductCard from '@/components/ProductCard';
import { products } from '@/data/products';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';

const Home = ({ navigateTo }) => {
  const categories = ['iPhones', 'MacBooks', 'Apple Watch', 'Fones', 'Acessórios'];
  const [selectedTab, setSelectedTab] = useState(categories[0]);

  const getProductsForCategory = (category) => {
    switch (category) {
      case 'iPhones':
        return products.filter(p => p.category === 'iPhone');
      case 'MacBooks':
        return products.filter(p => p.category === 'MacBook');
      case 'Apple Watch':
        return products.filter(p => p.category === 'Apple Watch');
      case 'Fones':
        return products.filter(p => p.category === 'AirPods');
      default:
        return [];
    }
  };

  const handleTabChange = (value) => {
    setSelectedTab(value);
    if (value === 'Acessórios') {
      toast({
        title: "Em breve!",
        description: "🚧 A categoria Acessórios será adicionada em breve! 🚀",
      });
    }
  };

  return (
    <div className="min-h-screen">
      <section className="relative h-[600px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#FF8A00]/20 via-transparent to-[#FFB84D]/20" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-block mb-6">
                <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-[#FF8A00] to-[#FFB84D] flex items-center justify-center glow-orange-strong">
                  <span className="text-6xl">🔥</span>
                </div>
              </div>
              <h1 className="text-5xl md:text-7xl font-bold mb-6">
                <span className="text-gradient-orange">HotiPhone</span>
                <br />
                <span className="text-[#E6E8EB]">STORE</span>
              </h1>
              <p className="text-xl md:text-2xl text-[#BFC3C7] mb-8 max-w-2xl mx-auto">
                iPhones, MacBooks e Acessórios Premium
                <br />
                <span className="text-[#FF8A00]">Parcelamento em até 12x</span> ou desconto no Pix
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' })}
                  className="px-8 py-4 bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] text-[#0E0E0E] font-bold rounded-lg glow-orange"
                >
                  Ver Ofertas
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#0E0E0E]/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Shield, title: '1 Ano de Garantia', desc: 'Qualidade Premium' },
              { icon: Truck, title: 'Entrega Rastreada', desc: 'Todo Brasil' },
              { icon: CreditCard, title: 'Pix ou 12x', desc: 'Sem Juros' },
              { icon: Award, title: 'Produtos Originais', desc: '100% Autênticos' }
            ].map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="text-center p-6 rounded-xl bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] border border-[#FF8A00]/20"
              >
                <item.icon className="w-12 h-12 mx-auto mb-4 text-[#FF8A00]" />
                <h3 className="font-bold text-[#E6E8EB] mb-2">{item.title}</h3>
                <p className="text-sm text-[#BFC3C7]">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="products-section" className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="text-gradient-orange">Nossos Produtos</span>
            </h2>
            <p className="text-[#BFC3C7]">Explore nossas categorias</p>
          </motion.div>

          <Tabs value={selectedTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-5 bg-transparent p-0 mb-8 gap-4">
              {categories.map((cat) => (
                <TabsTrigger
                  key={cat}
                  value={cat}
                  className="text-base text-[#BFC3C7] data-[state=active]:text-[#FF8A00] data-[state=active]:bg-[#FF8A00]/10 data-[state=active]:border-[#FF8A00] border border-transparent rounded-lg py-3 transition-all"
                >
                  {cat}
                </TabsTrigger>
              ))}
            </TabsList>
            {categories.map((cat) => (
              <TabsContent key={cat} value={cat}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {getProductsForCategory(cat).map((product, idx) => (
                    <ProductCard key={product.id} product={product} navigateTo={navigateTo} delay={idx * 0.1} />
                  ))}
                </div>
                {cat === 'Acessórios' && (
                  <div className="text-center py-16 text-[#BFC3C7]">
                    <p className="text-lg">Nossos acessórios incríveis chegarão em breve!</p>
                    <p>Fique de olho nas novidades. 👀</p>
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>
    </div>
  );
};

export default Home;