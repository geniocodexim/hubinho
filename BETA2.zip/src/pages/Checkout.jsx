import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CreditCard, QrCode, ArrowLeft, Check, UserPlus, KeyRound, MailCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';
import { formatCurrency } from '@/lib/formatCurrency';

const Checkout = ({ cart, navigateTo, clearCart }) => {
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('pix');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    token: '',
    cpf: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
    cardName: ''
  });

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 25;
  const pixPrice = (total * 0.95);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCepBlur = async () => {
    if (formData.cep.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${formData.cep}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setFormData({
            ...formData,
            address: data.logouro,
            neighborhood: data.bairro,
            city: data.localidade,
            state: data.uf
          });
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const handleRegistration = (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem.",
        variant: "destructive",
      });
      return;
    }
    toast({
      title: "Verificação necessária!",
      description: "Enviamos um código para seu e-mail e SMS. (Simulação: digite 123456)",
    });
    setStep(2);
  };

  const handleVerification = (e) => {
    e.preventDefault();
    if (formData.token === '123456') {
      toast({
        title: "Sucesso!",
        description: "Conta verificada. Continue com sua compra.",
      });
      setStep(3);
    } else {
      toast({
        title: "Erro",
        description: "Código de verificação inválido.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (paymentMethod === 'card') {
      if (formData.name.trim().toLowerCase() !== formData.cardName.trim().toLowerCase()) {
        toast({
          title: "Atenção!",
          description: "O nome do titular do cartão deve ser o mesmo do comprador. Para sua segurança, esta verificação será aprimorada no backend.",
          variant: "destructive",
          duration: 7000
        });
        return;
      }
    }
    
    const orderId = Math.random().toString(36).substr(2, 9).toUpperCase();
    
    localStorage.setItem('lastOrder', JSON.stringify({
      id: orderId,
      items: cart,
      total: paymentMethod === 'pix' ? pixPrice.toFixed(2) : total.toFixed(2),
      paymentMethod,
      status: 'awaiting_payment',
      createdAt: new Date().toISOString(),
      customer: formData
    }));

    clearCart();
    
    toast({
      title: "Pedido realizado! 🎉",
      description: `Pedido #${orderId} criado com sucesso!`,
    });

    navigateTo('account');
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <motion.div key="step1" initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 50 }}>
            <form onSubmit={handleRegistration} className="space-y-8">
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
                <h2 className="text-2xl font-bold text-[#E6E8EB] mb-6 flex items-center"><UserPlus className="mr-3 text-[#FF8A00]" /> Crie sua Conta</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-[#BFC3C7]">Nome Completo</Label>
                    <Input id="name" name="name" required value={formData.name} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-[#BFC3C7]">E-mail</Label>
                    <Input id="email" name="email" type="email" required value={formData.email} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-[#BFC3C7]">Telefone (com DDD)</Label>
                    <Input id="phone" name="phone" type="tel" required value={formData.phone} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="cpf" className="text-[#BFC3C7]">CPF</Label>
                    <Input id="cpf" name="cpf" required value={formData.cpf} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="password" className="text-[#BFC3C7]">Senha</Label>
                    <Input id="password" name="password" type="password" required value={formData.password} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="confirmPassword" className="text-[#BFC3C7]">Confirmar Senha</Label>
                    <Input id="confirmPassword" name="confirmPassword" type="password" required value={formData.confirmPassword} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                </div>
              </div>
              <Button type="submit" className="w-full py-6 text-lg bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] hover:from-[#FFB84D] hover:to-[#FF8A00] text-[#0E0E0E] font-bold glow-orange">
                <KeyRound className="w-5 h-5 mr-2" />
                Criar Conta e Continuar
              </Button>
            </form>
          </motion.div>
        );
      case 2:
        return (
          <motion.div key="step2" initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 50 }}>
            <form onSubmit={handleVerification} className="space-y-8">
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-8 border border-[#FF8A00]/20 text-center">
                <MailCheck className="w-16 h-16 mx-auto mb-4 text-[#FF8A00]" />
                <h2 className="text-2xl font-bold text-[#E6E8EB] mb-4">Verifique sua Conta</h2>
                <p className="text-[#BFC3C7] mb-6">Insira o código de 6 dígitos que enviamos para você.</p>
                <div className="max-w-sm mx-auto">
                  <Label htmlFor="token" className="sr-only">Código de Verificação</Label>
                  <Input id="token" name="token" required value={formData.token} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB] text-center text-2xl tracking-[1em]" maxLength={6} />
                </div>
              </div>
              <Button type="submit" className="w-full py-6 text-lg bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] hover:from-[#FFB84D] hover:to-[#FF8A00] text-[#0E0E0E] font-bold glow-orange">
                Verificar e Continuar
              </Button>
            </form>
          </motion.div>
        );
      case 3:
        return (
          <motion.div key="step3" initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }}>
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
                <h2 className="text-2xl font-bold text-[#E6E8EB] mb-6">Endereço de Entrega</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="cep" className="text-[#BFC3C7]">CEP</Label>
                    <Input id="cep" name="cep" required value={formData.cep} onChange={handleInputChange} onBlur={handleCepBlur} maxLength={8} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="address" className="text-[#BFC3C7]">Endereço</Label>
                    <Input id="address" name="address" required value={formData.address} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="number" className="text-[#BFC3C7]">Número</Label>
                      <Input id="number" name="number" required value={formData.number} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                    </div>
                    <div>
                      <Label htmlFor="complement" className="text-[#BFC3C7]">Complemento</Label>
                      <Input id="complement" name="complement" value={formData.complement} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="neighborhood" className="text-[#BFC3C7]">Bairro</Label>
                    <Input id="neighborhood" name="neighborhood" required value={formData.neighborhood} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="city" className="text-[#BFC3C7]">Cidade</Label>
                    <Input id="city" name="city" required value={formData.city} onChange={handleInputChange} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                  <div>
                    <Label htmlFor="state" className="text-[#BFC3C7]">Estado</Label>
                    <Input id="state" name="state" required value={formData.state} onChange={handleInputChange} maxLength={2} className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
                <h2 className="text-2xl font-bold text-[#E6E8EB] mb-6">Forma de Pagamento</h2>
                <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
                  <TabsList className="grid w-full grid-cols-2 bg-[#2a2a2a]">
                    <TabsTrigger value="pix" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]"><QrCode className="w-4 h-4 mr-2" />Pix</TabsTrigger>
                    <TabsTrigger value="card" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]"><CreditCard className="w-4 h-4 mr-2" />Cartão</TabsTrigger>
                  </TabsList>
                  <TabsContent value="pix" className="mt-6">
                    <div className="text-center p-8 bg-[#2a2a2a] rounded-lg">
                      <QrCode className="w-32 h-32 mx-auto mb-4 text-[#FF8A00]" />
                      <p className="text-[#BFC3C7] mb-4">Após confirmar o pedido, você receberá o QR Code para pagamento</p>
                      <div className="text-3xl font-bold text-gradient-orange">{formatCurrency(pixPrice)}</div>
                      <p className="text-sm text-[#BFC3C7] mt-2">5% de desconto no Pix</p>
                    </div>
                  </TabsContent>
                  <TabsContent value="card" className="mt-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardName" className="text-[#BFC3C7]">Nome no Cartão</Label>
                        <Input id="cardName" name="cardName" value={formData.cardName} onChange={handleInputChange} placeholder="Como impresso no cartão" className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                      </div>
                      <div>
                        <Label htmlFor="cardNumber" className="text-[#BFC3C7]">Número do Cartão</Label>
                        <Input id="cardNumber" placeholder="0000 0000 0000 0000" className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="cardExpiry" className="text-[#BFC3C7]">Validade</Label>
                          <Input id="cardExpiry" placeholder="MM/AA" className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                        </div>
                        <div>
                          <Label htmlFor="cardCvv" className="text-[#BFC3C7]">CVV</Label>
                          <Input id="cardCvv" placeholder="000" className="bg-[#2a2a2a] border-[#BFC3C7]/30 text-[#E6E8EB]" />
                        </div>
                      </div>
                      <div className="text-center p-4 bg-[#2a2a2a] rounded-lg">
                        <div className="text-2xl font-bold text-gradient-orange mb-2">12x de {formatCurrency(total / 12)}</div>
                        <p className="text-sm text-[#BFC3C7]">ou {formatCurrency(total)} à vista</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
                <h3 className="text-xl font-bold text-[#E6E8EB] mb-4">Resumo do Pedido</h3>
                <div className="space-y-2 mb-4">
                  {cart.map((item) => (
                    <div key={`${item.id}-${item.selectedColor}-${item.selectedCapacity}`} className="flex justify-between text-[#BFC3C7]">
                      <span>{item.name} ({item.quantity}x)</span>
                      <span>{formatCurrency(item.price * item.quantity)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-[#BFC3C7] pt-2 border-t border-[#FF8A00]/20">
                    <span>Frete</span>
                    <span>{formatCurrency(25)}</span>
                  </div>
                </div>
                <div className="flex justify-between text-2xl font-bold pt-4 border-t border-[#FF8A00]/20">
                  <span className="text-[#E6E8EB]">Total</span>
                  <span className="text-gradient-orange">{formatCurrency(paymentMethod === 'pix' ? pixPrice : total)}</span>
                </div>
              </div>

              <Button type="submit" className="w-full py-6 text-lg bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] hover:from-[#FFB84D] hover:to-[#FF8A00] text-[#0E0E0E] font-bold glow-orange">
                <Check className="w-5 h-5 mr-2" />
                Confirmar Pedido
              </Button>
            </form>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button
          variant="ghost"
          onClick={() => step === 1 ? navigateTo('cart') : setStep(step - 1)}
          className="mb-6 text-[#BFC3C7] hover:text-[#FF8A00]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {step === 1 ? 'Voltar ao Carrinho' : 'Voltar'}
        </Button>

        <h1 className="text-4xl font-bold mb-8">
          <span className="text-gradient-orange">Finalizar Compra</span>
        </h1>

        <AnimatePresence mode="wait">
          {renderStep()}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Checkout;