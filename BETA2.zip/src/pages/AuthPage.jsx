
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AtSign, Lock, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const AuthPage = ({ navigateTo }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();

  const handleSignIn = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await signIn(email, password);
    if (!error) {
      toast({
        title: 'Login bem-sucedido!',
        description: 'Bem-vindo de volta!',
        className: 'bg-green-500 text-white',
      });
      navigateTo('account');
    }
    setLoading(false);
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await signUp(email, password, {
      data: {
        role: 'customer', // Default role
      },
    });
    if (!error) {
      toast({
        title: 'Cadastro realizado com sucesso!',
        description: 'Verifique seu e-mail para confirmar sua conta.',
        className: 'bg-green-500 text-white',
      });
      // Optionally navigate to a "check your email" page or back to login
    }
    setLoading(false);
  };

  return (
    <div className="min-h-[calc(100vh-120px)] flex items-center justify-center p-4 text-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-[#2a2a2a]">
            <TabsTrigger value="signin" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]">
              <User className="w-4 h-4 mr-2" />
              Entrar
            </TabsTrigger>
            <TabsTrigger value="signup" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]">
              <User className="w-4 h-4 mr-2" />
              Cadastrar
            </TabsTrigger>
          </TabsList>
          <TabsContent value="signin">
            <div className="bg-[#1a1a1a] p-8 rounded-b-lg border border-t-0 border-[#FF8A00]/20">
              <h2 className="text-2xl font-bold text-center mb-2 text-gradient-orange">Bem-vindo de volta!</h2>
              <p className="text-center text-sm text-[#BFC3C7] mb-6">Faça login para continuar.</p>
              <form onSubmit={handleSignIn} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email-signin">Email</Label>
                  <div className="relative">
                    <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#BFC3C7]" />
                    <Input
                      id="email-signin"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-[#0E0E0E] border-[#333] pl-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password-signin">Senha</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#BFC3C7]" />
                    <Input
                      id="password-signin"
                      type="password"
                      placeholder="********"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-[#0E0E0E] border-[#333] pl-10"
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] text-black font-bold" disabled={loading}>
                  {loading ? 'Entrando...' : 'Entrar'}
                </Button>
              </form>
            </div>
          </TabsContent>
          <TabsContent value="signup">
            <div className="bg-[#1a1a1a] p-8 rounded-b-lg border border-t-0 border-[#FF8A00]/20">
              <h2 className="text-2xl font-bold text-center mb-2 text-gradient-orange">Crie sua conta</h2>
              <p className="text-center text-sm text-[#BFC3C7] mb-6">É rápido e fácil.</p>
              <form onSubmit={handleSignUp} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email-signup">Email</Label>
                  <div className="relative">
                    <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#BFC3C7]" />
                    <Input
                      id="email-signup"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-[#0E0E0E] border-[#333] pl-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password-signup">Senha</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#BFC3C7]" />
                    <Input
                      id="password-signup"
                      type="password"
                      placeholder="Crie uma senha forte"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-[#0E0E0E] border-[#333] pl-10"
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] text-black font-bold" disabled={loading}>
                  {loading ? 'Criando conta...' : 'Cadastrar'}
                </Button>
              </form>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
};

export default AuthPage;
