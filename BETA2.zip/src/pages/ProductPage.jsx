import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ShoppingCart, ShieldCheck, Truck, Zap } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { formatCurrency } from '@/lib/formatCurrency';

const ProductPage = ({ product, navigateTo, addToCart }) => {
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [selectedCapacity, setSelectedCapacity] = useState(product.capacities[0]);
  const [selectedImage, setSelectedImage] = useState(product.images[0]);

  const installmentPrice = product.price / 12;
  const pixPrice = product.price * 0.9;

  const handleAddToCart = () => {
    addToCart({
      ...product,
      image: product.images[0],
      selectedColor,
      selectedCapacity,
    });
    toast({
      title: "Adicionado ao Carrinho! 🛒",
      description: `${product.name} (${selectedCapacity}) foi adicionado ao seu carrinho.`,
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        <Button
          variant="ghost"
          onClick={() => navigateTo('home')}
          className="mb-6 text-[#BFC3C7] hover:text-[#FF8A00]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para a loja
        </Button>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-2xl p-8 border border-[#FF8A00]/20 mb-4">
              <motion.img
                key={selectedImage}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="w-full h-auto object-contain rounded-lg max-h-[400px]"
                alt={`Imagem do ${product.name} na cor ${selectedColor}`}
                src={selectedImage} />
            </div>
            <div className="flex gap-3 justify-center">
              {product.images.map((img, index) => (
                <div
                  key={index}
                  onClick={() => setSelectedImage(img)}
                  className={`w-20 h-20 rounded-lg cursor-pointer border-2 transition-all duration-200 ${selectedImage === img ? 'border-[#FF8A00] scale-105' : 'border-transparent hover:border-[#FF8A00]/50'}`}
                >
                  <img src={img} alt={`Thumbnail ${index + 1} do ${product.name}`} className="w-full h-full object-cover rounded-md" />
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col h-full"
          >
            <h1 className="text-4xl font-bold mb-4">
              <span className="text-gradient-orange">{product.name}</span>
            </h1>
            <p className="text-[#BFC3C7] mb-6 text-lg">{product.description}</p>

            <div className="mb-6">
              <h3 className="text-lg font-semibold text-[#E6E8EB] mb-3">Cor</h3>
              <div className="flex space-x-3">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border-2 transition-all duration-200 ${selectedColor === color ? 'border-[#FF8A00] scale-110' : 'border-transparent'}`}
                    style={{ backgroundColor: color.toLowerCase() === 'preto' ? '#333' : color.toLowerCase() === 'branco' ? '#f0f0f0' : color.toLowerCase() }}
                    aria-label={`Selecionar cor ${color}`}
                  />
                ))}
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-[#E6E8EB] mb-3">Capacidade</h3>
              <div className="flex space-x-3">
                {product.capacities.map((capacity) => (
                  <Button
                    key={capacity}
                    variant={selectedCapacity === capacity ? 'default' : 'outline'}
                    onClick={() => setSelectedCapacity(capacity)}
                    className={`
                      ${selectedCapacity === capacity
                        ? 'bg-[#FF8A00] text-[#0E0E0E] border-[#FF8A00]'
                        : 'bg-transparent text-[#BFC3C7] border-[#BFC3C7]/50 hover:bg-[#2a2a2a] hover:text-white'}
                    `}
                  >
                    {capacity}
                  </Button>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20 mb-8">
              <p className="text-4xl font-bold text-gradient-orange mb-2">12x de {formatCurrency(installmentPrice)}</p>
              <p className="text-xl text-[#BFC3C7]">ou {formatCurrency(pixPrice)} no PIX</p>
              <p className="text-sm text-green-400 mt-2 flex items-center"><Zap className="w-4 h-4 mr-1" /> 10% de desconto no PIX</p>
            </div>

            <Button
              onClick={handleAddToCart}
              size="lg"
              className="w-full py-8 text-xl bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] hover:from-[#FFB84D] hover:to-[#FF8A00] text-[#0E0E0E] font-bold glow-orange"
            >
              <ShoppingCart className="w-6 h-6 mr-3" />
              Adicionar ao Carrinho
            </Button>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4 text-[#BFC3C7]">
              <div className="flex items-center space-x-3">
                <ShieldCheck className="w-6 h-6 text-[#FF8A00]" />
                <span>Garantia Apple de 1 ano</span>
              </div>
              <div className="flex items-center space-x-3">
                <Truck className="w-6 h-6 text-[#FF8A00]" />
                <span>Entrega para todo Brasil</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;