
    import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Package, Truck, ShoppingBag, CreditCard, Home as HomeIcon, User, MapPin, Shield, ClipboardCopy, PackageCheck, LogOut } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { formatCurrency } from '@/lib/formatCurrency';

const OrderTimeline = ({ status }) => {
  const statuses = [
    { id: 'Pedido realizado', text: 'Pedido Realizado', icon: ShoppingBag },
    { id: 'Pagamento confirmado', text: 'Pagamento Confirmado', icon: CreditCard },
    { id: 'Produto em preparação', text: 'Produto em Preparação', icon: Package },
    { id: 'Produto enviado', text: 'Produto Enviado', icon: Truck },
    { id: 'Entregue', text: 'Entregue', icon: HomeIcon },
  ];

  const currentStatusIndex = statuses.findIndex(s => s.id === status);

  return (
    <div className="w-full mt-6 mb-8">
      <div className="flex items-center justify-between">
        {statuses.map((s, index) => (
          <div key={s.id} className="flex flex-col items-center text-center w-1/5">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${index <= currentStatusIndex ? 'bg-[#FF8A00] border-[#FFB84D] text-[#0E0E0E]' : 'bg-[#2a2a2a] border-[#444] text-[#BFC3C7]'}`}>
              <s.icon className="w-5 h-5" />
            </div>
            <p className={`mt-2 text-xs font-semibold ${index <= currentStatusIndex ? 'text-[#E6E8EB]' : 'text-[#BFC3C7]'}`}>{s.text}</p>
          </div>
        ))}
      </div>
      <div className="relative w-full h-1 bg-[#2a2a2a] mt-[-28px] -z-10">
        <motion.div
          className="absolute top-0 left-0 h-1 bg-gradient-to-r from-[#FF8A00] to-[#FFB84D]"
          initial={{ width: '0%' }}
          animate={{ width: `${(currentStatusIndex / (statuses.length - 1)) * 100}%` }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
        />
      </div>
    </div>
  );
};

const ProfileTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({ full_name: '', email: '', phone: '', document: '' });

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;
      const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      if (data) {
        setProfile({
          full_name: data.full_name || '',
          email: data.email || '',
          phone: data.phone || '',
          document: data.document || '',
        });
      }
    };
    fetchProfile();
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: profile.full_name,
        phone: profile.phone,
        document: profile.document,
      })
      .eq('id', user.id);
    
    if (error) {
      toast({ title: "Erro ao atualizar perfil", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Perfil atualizado com sucesso!", className: "bg-green-500 text-white" });
    }
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
      <h3 className="text-2xl font-bold text-[#E6E8EB] mb-6">Dados Pessoais</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="full_name">Nome Completo</Label>
          <Input id="full_name" name="full_name" value={profile.full_name} onChange={handleInputChange} className="bg-[#0E0E0E] border-[#333]" />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" value={profile.email} disabled className="bg-[#0E0E0E] border-[#333] opacity-50" />
        </div>
        <div>
          <Label htmlFor="phone">Telefone</Label>
          <Input id="phone" name="phone" value={profile.phone} onChange={handleInputChange} className="bg-[#0E0E0E] border-[#333]" />
        </div>
        <div>
          <Label htmlFor="document">CPF/CNPJ</Label>
          <Input id="document" name="document" value={profile.document} onChange={handleInputChange} className="bg-[#0E0E0E] border-[#333]" />
        </div>
        <Button type="submit" disabled={loading} className="bg-gradient-to-r from-[#FF8A00] to-[#FFB84D] text-black font-bold">
          {loading ? 'Salvando...' : 'Salvar Alterações'}
        </Button>
      </form>
    </div>
  );
};

const Account = ({ navigateTo, isAdmin }) => {
  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const { toast } = useToast();
  const { user, signOut } = useAuth();

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;
      setLoadingOrders(true);
      const { data, error } = await supabase
        .from('orders')
        .select('*, order_items(*, products!inner(name, images))')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        toast({ title: "Erro ao buscar pedidos", description: error.message, variant: "destructive" });
      } else {
        setOrders(data);
      }
      setLoadingOrders(false);
    };

    fetchOrders();
  }, [user, toast]);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copiado!",
      description: "Código de rastreio copiado para a área de transferência.",
    });
  };

  const handleSignOut = async () => {
    await signOut();
    navigateTo('home');
    toast({
      title: "Logout realizado com sucesso!",
      description: "Esperamos ver você novamente em breve.",
    });
  };

  return (
    <div className="min-h-screen py-8 text-white">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">
            <span className="text-gradient-orange">Minha Conta</span>
          </h1>
          <div>
            {isAdmin && (
              <Button variant="outline" onClick={() => navigateTo('admin')} className="border-[#FF8A00] text-[#FF8A00] hover:bg-[#FF8A00] hover:text-[#0E0E0E] mr-4">
                <Shield className="w-4 h-4 mr-2" />
                Painel Admin
              </Button>
            )}
            <Button variant="destructive" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>

        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-[#2a2a2a] mb-8">
            <TabsTrigger value="orders" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]">
              <Package className="w-4 h-4 mr-2" />
              Pedidos
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]">
              <User className="w-4 h-4 mr-2" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="addresses" className="data-[state=active]:bg-[#FF8A00] data-[state=active]:text-[#0E0E0E]">
              <MapPin className="w-4 h-4 mr-2" />
              Endereços
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            {loadingOrders ? (
              <div className="text-center py-16">Carregando pedidos...</div>
            ) : orders.length === 0 ? (
              <div className="text-center py-16">
                <Package className="w-24 h-24 mx-auto mb-4 text-[#BFC3C7]" />
                <h3 className="text-2xl font-bold text-[#E6E8EB] mb-2">Nenhum pedido ainda</h3>
                <p className="text-[#BFC3C7]">Faça seu primeiro pedido!</p>
              </div>
            ) : (
              <div className="space-y-6">
                {orders.map((order) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20"
                  >
                    <div className="flex flex-wrap items-start justify-between mb-4">
                      <div>
                        <h3 className="text-2xl font-bold text-[#E6E8EB] mb-2">
                          Pedido #{order.id}
                        </h3>
                        <p className="text-sm text-[#BFC3C7]">
                          {new Date(order.created_at).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-[#BFC3C7]">Total</span>
                        <span className="block text-2xl font-bold text-gradient-orange">
                          {formatCurrency(order.total_price)}
                        </span>
                      </div>
                    </div>

                    <OrderTimeline status={order.status} />

                    {order.status === 'Produto enviado' && order.tracking_code && (
                      <div className="my-6 p-4 bg-[#2a2a2a] rounded-lg flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-[#E6E8EB] flex items-center gap-2">
                            <Truck className="w-5 h-5 text-[#FF8A00]" />
                            Código de Rastreio
                          </h4>
                          <p className="text-lg font-mono text-[#BFC3C7]">{order.tracking_code}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => copyToClipboard(order.tracking_code)}>
                          <ClipboardCopy className="w-5 h-5 text-[#FF8A00]" />
                        </Button>
                      </div>
                    )}
                    
                    {order.status === 'Entregue' && (
                       <div className="my-6 p-4 bg-green-900/20 border border-green-500/30 rounded-lg flex items-center gap-4">
                          <PackageCheck className="w-8 h-8 text-green-400 flex-shrink-0" />
                          <div>
                            <h4 className="font-semibold text-green-300">Produto Entregue</h4>
                            <p className="text-sm text-green-400">Seu pedido foi entregue com sucesso. Esperamos que goste!</p>
                          </div>
                        </div>
                    )}

                    <div className="space-y-4">
                      {order.order_items.map((item) => (
                        <div key={item.id} className="flex gap-4 p-4 bg-[#2a2a2a] rounded-lg">
                          <div className="w-20 h-20 bg-gradient-to-br from-[#3a3a3a] to-[#2a2a2a] rounded-lg p-2 flex-shrink-0">
                            <img src={item.products.images[0]} alt={item.products.name} className="w-full h-full object-contain" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-[#E6E8EB]">{item.products.name}</h4>
                            <p className="text-sm text-[#BFC3C7]">
                              {item.color} • {item.capacity}
                            </p>
                            <p className="text-sm text-[#BFC3C7]">Quantidade: {item.quantity}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-[#FF8A00]">
                              {formatCurrency(item.price * item.quantity)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="profile">
            <ProfileTab />
          </TabsContent>

          <TabsContent value="addresses">
            <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0E0E0E] rounded-xl p-6 border border-[#FF8A00]/20">
              <h3 className="text-2xl font-bold text-[#E6E8EB] mb-6">Meus Endereços</h3>
              <p className="text-[#BFC3C7]">
                🚧 Funcionalidade de endereços será implementada em breve! 🚀
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Account;
  