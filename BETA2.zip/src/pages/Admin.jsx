import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Package, ShoppingCart, Users, BarChart2, Truck, CreditCard, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';
import ProductManagement from '@/components/admin/ProductManagement';
import OrderManagement from '@/components/admin/OrderManagement';
import CustomerManagement from '@/components/admin/CustomerManagement';
import { useToast } from '@/components/ui/use-toast';

const PlaceholderContent = ({ title, description }) => (
  <div className="text-center py-16">
    <h3 className="text-2xl font-bold text-[#E6E8EB] mb-2">{title}</h3>
    <p className="text-[#BFC3C7]">{description}</p>
  </div>
);

const Admin = ({ navigateTo }) => {
  const [activeTab, setActiveTab] = useState('products');
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchProducts = async () => {
    const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Erro ao buscar produtos", description: error.message, variant: "destructive" });
    } else {
      setProducts(data);
    }
  };

  const fetchOrders = async () => {
    const { data, error } = await supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false });
     if (error) {
      toast({ title: "Erro ao buscar pedidos", description: error.message, variant: "destructive" });
    } else {
      setOrders(data);
    }
  };

  const fetchCustomers = async () => {
    const { data, error } = await supabase.from('profiles').select('*').order('email', { ascending: true });
    if (error) {
      toast({ title: "Erro ao buscar clientes", description: error.message, variant: "destructive" });
    } else {
      setCustomers(data);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await Promise.all([fetchProducts(), fetchOrders(), fetchCustomers()]);
      setLoading(false);
    };
    fetchData();
  }, []);

  const renderContent = () => {
    if (loading) {
      return <div className="text-center p-10">Carregando dados da loja...</div>;
    }
    switch (activeTab) {
      case 'products':
        return <ProductManagement products={products} refreshProducts={fetchProducts} />;
      case 'orders':
        return <OrderManagement orders={orders} refreshOrders={fetchOrders} />;
      case 'customers':
        return <CustomerManagement customers={customers} refreshCustomers={fetchCustomers} />;
      case 'sellers':
        return <PlaceholderContent title="Gerenciamento de Vendedores" description="🚧 Esta funcionalidade será implementada em breve! Você poderá cadastrar e gerenciar seus vendedores aqui. 🚀" />;
      case 'delivery':
        return <PlaceholderContent title="Métodos de Entrega" description="🚧 Esta funcionalidade será implementada em breve! Integre com os Correios e outras transportadoras. 🚀" />;
      case 'payments':
        return <PlaceholderContent title="Métodos de Pagamento" description="🚧 Esta funcionalidade será implementada em breve! Configure Pix, Cartão de Crédito e mais. 🚀" />;
      case 'analytics':
        return <PlaceholderContent title="Análises" description="🚧 Esta funcionalidade será implementada em breve! Tenha insights sobre suas vendas. 🚀" />;
      default:
        return <ProductManagement products={products} refreshProducts={fetchProducts} />;
    }
  };

  const getTabClass = (tabName) => {
    return `flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors duration-300 ${
      activeTab === tabName
        ? 'bg-[#FF8A00] text-[#0E0E0E] font-semibold'
        : 'text-[#BFC3C7] hover:bg-[#2a2a2a]'
    }`;
  };

  return (
    <div className="min-h-screen py-8 text-white">
      <div className="container mx-auto px-4 max-w-7xl">
        <Button
          variant="ghost"
          onClick={() => navigateTo('account')}
          className="mb-6 text-[#BFC3C7] hover:text-[#FF8A00]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para Minha Conta
        </Button>

        <h1 className="text-4xl font-bold mb-2">
          <span className="text-gradient-orange">Painel do Administrador</span>
        </h1>
        <p className="text-[#BFC3C7] mb-8">
          Gerencie sua loja, produtos e pedidos em tempo real.
        </p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a1a] rounded-xl border border-[#FF8A00]/20"
        >
          <div className="p-4 border-b border-[#FF8A00]/20 overflow-x-auto">
            <nav className="flex items-center space-x-2">
              <button onClick={() => setActiveTab('products')} className={getTabClass('products')}>
                <Package className="w-5 h-5" />
                <span>Produtos</span>
              </button>
              <button onClick={() => setActiveTab('orders')} className={getTabClass('orders')}>
                <ShoppingCart className="w-5 h-5" />
                <span>Pedidos</span>
              </button>
              <button onClick={() => setActiveTab('customers')} className={getTabClass('customers')}>
                <Users className="w-5 h-5" />
                <span>Clientes</span>
              </button>
              <button onClick={() => setActiveTab('sellers')} className={getTabClass('sellers')}>
                <UserPlus className="w-5 h-5" />
                <span>Vendedores</span>
              </button>
              <button onClick={() => setActiveTab('delivery')} className={getTabClass('delivery')}>
                <Truck className="w-5 h-5" />
                <span>Entregas</span>
              </button>
              <button onClick={() => setActiveTab('payments')} className={getTabClass('payments')}>
                <CreditCard className="w-5 h-5" />
                <span>Pagamentos</span>
              </button>
              <button onClick={() => setActiveTab('analytics')} className={getTabClass('analytics')}>
                <BarChart2 className="w-5 h-5" />
                <span>Análises</span>
              </button>
            </nav>
          </div>
          <div className="p-6">
            {renderContent()}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Admin;