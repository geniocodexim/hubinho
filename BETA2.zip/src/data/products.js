export const products = [
  {
    id: 1,
    name: 'iPhone 16 Pro Max',
    description: 'O mais poderoso iPhone já criado. Chip A18 Pro, câmera de 48MP com zoom óptico 5x, tela Super Retina XDR de 6.9".',
    price: 9999.00,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80',
      'https://images.unsplash.com/photo-1678939643713-449893de11ab?w=800&q=80',
      'https://images.unsplash.com/photo-1694351642716-a614111b0414?w=800&q=80',
      'https://images.unsplash.com/photo-1694351642716-a614111b0414?w=800&q=80'
    ],
    colors: ['Titânio Natural', 'Titânio Azul', 'Titânio Preto', 'Titânio Branco'],
    capacities: ['256GB', '512GB', '1TB'],
    category: 'iPhone'
  },
  {
    id: 2,
    name: 'iPhone 16 Pro',
    description: 'Performance profissional em tamanho compacto. Chip A18 Pro, câmera tripla de 48MP, tela de 6.3".',
    price: 8499.00,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80',
      'https://images.unsplash.com/photo-1678939643713-449893de11ab?w=800&q=80',
      'https://images.unsplash.com/photo-1694351642716-a614111b0414?w=800&q=80'
    ],
    colors: ['Titânio Natural', 'Titânio Azul', 'Titânio Preto', 'Titânio Branco'],
    capacities: ['128GB', '256GB', '512GB', '1TB'],
    category: 'iPhone'
  },
  {
    id: 3,
    name: 'iPhone 16',
    description: 'O iPhone essencial com tudo que você precisa. Chip A18, câmera dupla de 48MP, tela de 6.1".',
    price: 6999.00,
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=80',
      'https://images.unsplash.com/photo-1678939643713-449893de11ab?w=800&q=80'
    ],
    colors: ['Preto', 'Branco', 'Rosa', 'Azul', 'Verde'],
    capacities: ['128GB', '256GB', '512GB'],
    category: 'iPhone'
  },
  {
    id: 4,
    name: 'MacBook Pro 16"',
    description: 'Poder extremo para profissionais. Chip M3 Max, 36GB RAM, tela Liquid Retina XDR.',
    price: 24999.00,
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80',
      'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=800&q=80',
      'https://images.unsplash.com/photo-1537498425277-c283d32ef9db?w=800&q=80'
    ],
    colors: ['Cinza Espacial', 'Prata'],
    capacities: ['512GB', '1TB', '2TB'],
    category: 'MacBook'
  },
  {
    id: 5,
    name: 'Apple Watch Series 9',
    description: 'Seu parceiro de saúde e fitness. Tela sempre ativa, sensor de temperatura, detecção de acidentes.',
    price: 4299.00,
    images: [
      'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=800&q=80',
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=80',
      'https://images.unsplash.com/photo-1579586337278-35d99a4a89b5?w=800&q=80'
    ],
    colors: ['Meia-noite', 'Estelar', 'Prata', 'Rosa'],
    capacities: ['41mm', '45mm'],
    category: 'Apple Watch'
  },
  {
    id: 6,
    name: 'AirPods Pro (2ª geração)',
    description: 'Cancelamento de ruído adaptativo, áudio espacial personalizado, até 6h de bateria.',
    price: 2299.00,
    images: [
      'https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=800&q=80',
      'https://images.unsplash.com/photo-1610438235354-a6ae5528385c?w=800&q=80',
      'https://images.unsplash.com/photo-1590658263928-965c469320c7?w=800&q=80'
    ],
    colors: ['Branco'],
    capacities: ['Padrão'],
    category: 'AirPods'
  }
];